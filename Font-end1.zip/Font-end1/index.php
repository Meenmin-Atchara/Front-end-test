<!DOCTYPE html>
<html lang="en">
<head>
  <title>Font-end Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="layout.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"></head>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


</head>
<body>

<nav class="navbar navbar-expand-sm  navbar-dark fixed-top" style="background-color: white;">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="Image/Logo/logo.png" alt="logo" style="margin-left:225px; height:20px; width:60px; ">
  </a>
  
  <!-- Input bar -->
  <form class="form-inline" action="/action_page.php">
    <input class="form-control mr-sm-2" type="text" placeholder="&#xF002; ค้นหา" style="width: 604px; border-radius: 10px;">  </form>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#" style="color: black;">หน้าแรก</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#" style="color: black;">เกี่ยวกับ</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#" style="color: black;">ติดต่อเรา</a>
    </li>

  <!-- Button -->
    <form class="form-inline" action="/action_page.php">
      <button type="submit" class="button" style="background-color:#E5E5E5;">Register</button> 
      <button type="button" class="button" style="border: 1px solid; margin-left: 10px;">Sign In</button>
    </form>
  </ul>
</nav>

<!-- Content -->
<div class="container-fluid"style="margin-top:56px">
  <div class="row">

  <!-- Header -->
      <div class="col-md-12" style="background-color:#FFFF; text-align: center;">
       <img src="Image/Logo/logo5.png" style="margin:25px 0 20px 0; width="180px" height="35px">
      </div>

  <!-- Box -->
        <div id="box" class="box">
          <!--Box content -->
          <div class="content">
            <span class="closebox ">&times;</span>
            <label class="textbox">Ads</label>
          </div>

          <div class="content2">
            <span class="closebox2">&times;</span>
            <label class="textbox">Ads</label>
          </div>

          <div class="content3">
            <span class="closebox3"><label style="margin-left:10px;  cursor: pointer;">ปิด</label>&times; </span>
            <label class="textbox3">Ads</label>
          </div>
        </div>

  <!-- L-Side -->
    <div class="col-md-2"></div>
    
  <!-- Content  -->
    <div class="col-md-8" style="background-color:#FFFF;">
      <!-- Slide Images -->
        <div id="demo" class="carousel slide" data-ride="carousel">

          <!-- Indicators -->
          <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active" style="background-color: #00AEEF;"></li>
            <li data-target="#demo" data-slide-to="1" style="background-color: #00AEEF;"></li>
            <li data-target="#demo" data-slide-to="2" style="background-color: #00AEEF;"></li>
          </ul>
          
          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="Image/Content/slide.png" width="100%" height="100%">
            </div>
            <div class="carousel-item">
              <img src="Image/Content/slide.png" width="100%" height="100%">
            </div>
            <div class="carousel-item">
              <img src="Image/Content/slide.png" width="100%" height="100%">
            </div>
          </div>
          
          <!-- Left and right controls -->
          <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon" style="background-color: #2E3A59;"></span>
          </a>
          <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon" style="background-color: #2E3A59;"></span>
          </a>
        </div>
      <!--End Slide Image -->

      <!-- Images Button -->
      <div class="container" style="text-align: center; margin: 25px 0 25px 0;">
      
      <!-- <img src="Image/Button/button3.png" height="100px;"> -->  
        <div class="row">  
            <div class="col-md-4">
              <a href="#">
                <img src="Image/Button/b1.png" height="100px;" style="float:right;">
                <!-- <label class="center" style="top: 40%; width: 90%;">โครงการใหม่</label>  -->
              </a>
            </div>

            <div class="col-md-4">
              <a href="#">
                <img src="Image/Button/b2.png" height="100px;" style="float: center;">
              </a>
            </div>

            <div class="col-md-4">
              <a href="#">
                <img src="Image/Button/b3.png" height="100px;" style="float: left;">
              </a>
            </div>
        </div> 

     
      </div>
    <!-- content1 -->
      <div class="row" style="margin: 20px 0 15px 0px;">
        <div class="col-md-6">
          <a href="#"><img src="Image/Content/text1.png" style="width: 180px;"></a>
        </div>
        <div class="col-md-6">
          <a href="#"><img src="Image/Content/text.png" class="rightcon"></a>
        </div>
      </div>
    <!-- img content -->
      <div class="row">
        <div class="col-md-3">
          <a href="#"><img src="Image/Content/Picture1.png" class="imgbox"></a>        
        </div>
        <div class="col-md-3">
          <a href="#"><img src="Image/Content/Picture2.png" class="imgbox"></a>        
        </div>
        <div class="col-md-3">
          <a href="#"><img src="Image/Content/Picture3.png" class="imgbox"></a>        
        </div>
        <div class="col-md-3">
          <a href="#"><img src="Image/Content/Picture4.png" class="imgbox"></a>        
        </div>
      </div>

  <!-- content2 -->
      <div class="row" style="margin: 20px 0 15px 0px;">
        <div class="col-md-6">
          <a href="#"><img src="Image/Content/text2.png" style="width: 250px;"></a>
        </div>
        <div class="col-md-6">
          <a href="#"><img src="Image/Content/text.png" class="rightcon"></a>
        </div>
      </div>
    <!-- img content -->
      <div class="row">
        <div class="col-md-6">
          <a href="#"><img src="Image/Content/Picture5.png" class="imgbox"></a>        
        </div>
        <div class="col-md-6">
          <a href="#"><img src="Image/Content/Picture6.png" class="imgbox"></a>        
        </div>
      </div>

      <!-- content3 -->
      <div class="row" style="margin: 20px 0 15px 0px;">
        <div class="col-md-6">
          <a href="#"><img src="Image/Content/text3.png" style="width: 290px;"></a>
        </div>
        <div class="col-md-6">
          <a href="#"><img src="Image/Content/text.png" class="rightcon"></a>
        </div>
      </div>
    <!-- img content -->
      <div class="row" style="margin-bottom: 65px;">
        <div class="col-md-3">
          <a href="#"><img src="Image/Content/Picture7.png" class="imgbox"></a>        
        </div>
        <div class="col-md-3">
          <a href="#"><img src="Image/Content/Picture8.png" class="imgbox"></a>        
        </div>
        <div class="col-md-3">
          <a href="#"><img src="Image/Content/Picture9.png" class="imgbox"></a>        
        </div>
        <div class="col-md-3">
          <a href="#"><img src="Image/Content/Picture10.png" class="imgbox"></a>        
        </div>
      </div>

    </div>

  <!-- R-Side  -->
    <div class="col-md-2"></div>

  <!-- Footer -->
    <div class="col-md-7" style="background-color:#FFFFFF; margin-bottom: 30px;">
        <header class="w3-container" style="height:150px;">
           <strong style="float:left;" >
            <label style="font-size: 26px;">Contact Us</label> <br>
            <label><img src="Image/Icon/icon1.png" width="25px" style="margin-right: 10px;">099-9999-999</label> <br>
            <label><img src="Image/Icon/icon2.png" width="25px" style="margin-right: 10px;">Test@gmail.com</label> <br>
            <img src="Image/Icon/icon3.png" width="25px" style="margin-right: 10px;">
            <img src="Image/Icon/icon4.png" width="25px" style="margin-right: 10px;">
           </strong>
        </header> 

    </div>

    <div class="col-md-5" style="background-color:#FFFFFF; margin-bottom: 30px;">

        <header class="w3-container" style="height:150px;">
           <strong style="float:right;" >
            <a href="#"><label class="textfoot">Terms & Conditions</label></a>
            <a href="#"><label style="margin-left: 30px;" class="textfoot">Privacy Policy</label></a>
            <a href="#"><label style="margin-left: 30px;" class="textfoot">Cookie Policy</label></a>
           </strong>
        </header>

        <footer class="w3-container">
           <strong class="textfoot" style="float:right;">© Copyright </strong>
        </footer>

  </div>
</div>

</body>
</html>

  <script src="layout.js"></script>
