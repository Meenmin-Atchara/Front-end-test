
var box = document.getElementById("box");
var content = document.getElementsByClassName("content")[0];
var content2 = document.getElementsByClassName("content2")[0];
var content3 = document.getElementsByClassName("content3")[0];

var span = document.getElementsByClassName("closebox")[0];
var span2 = document.getElementsByClassName("closebox2")[0];
var span3 = document.getElementsByClassName("closebox3")[0];


window.onload = function() {
  box.style.display = "block";
}

// close <span4> (x)
span.onclick = function() {
 content.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == box) {
//   content.style.display = "none";
//   }
// }

// close <span2> (x)
span2.onclick = function() {
  content2.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == box) {
//    content2.style.display = "none";
//   }
// }

// close <span3> (x)
span3.onclick = function() {
  content3.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == box) {
//    content3.style.display = "none";
//   }
// }
