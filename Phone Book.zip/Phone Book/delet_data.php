<?php

$id = $_GET['id']

// $url = 'https://test-frontend-api.nayoo.co/api/Nayoo/1602/destroy?id={id}';

// $ch  = curl_init();
// curl_setopt($ch, CURLOPT_URL,$url);
// curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
// curl_setopt($ch, CURLOPT_POSTFIELDS, $_GET['id']);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// $result = curl_exec($ch);
// $result = json_decode($result);
// curl_close($ch);

    $url = $this->'https://test-frontend-api.nayoo.co/api/Nayoo/1602/destroy/?id={id}';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $result;
