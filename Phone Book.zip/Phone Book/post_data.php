<?php
//POST DATA

$name = $_POST['name'];
$organization = $_POST['organization'];
$mobilenumber = $_POST['mobilenumber'];
$homephone = $_POST['homephone'];
$officenumber = $_POST['officenumber'];
$email = $_POST['email'];
$image = $_FILES['image'];

//API Url
$url = 'https://test-frontend-api.nayoo.co/api/Nayoo/1602/store';

//Initiate cURL.
$ch = curl_init($url);

//The JSON data.
$jsonData = array(
    'name' =>  $name,
    'organization' =>  $organization,
    'mobilenumber' =>  $mobilenumber,
    'homephone' =>  $homephone,
    'officenumber' =>  $officenumber,
    'email' =>  $email,
    'image' => $image
    
);

//Encode the array into JSON.
$jsonDataEncoded = json_encode($jsonData);

//Tell cURL that we want to send a POST request.
curl_setopt($ch, CURLOPT_POST, 1);

//Attach our encoded JSON string to the POST fields.
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);

//Set the content type to application/json
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 

//Execute the request
$result = curl_exec($ch);

    
    if ($result){
    echo "<script type='text/javascript'>";
        echo "alert('Successfully created');";
        echo"window.location = 'show_all.php'; ";
    echo"</script>";
    }
    else {
    //ไม่สำเร็จ  
      echo "<script type='text/javascript'>";
          echo "alert('Error! Please Try Agian.');";
          echo"window.location = 'create.php'; ";
      echo"</script>";
    }