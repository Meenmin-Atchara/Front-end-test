<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="layout.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>

<title>Phone Book</title>

<style> </style>

</head>
<body>

    <?php
      // error_reporting(0); 
      // $id = $_POST['id'];

      $get_data=file_get_contents('https://test-frontend-api.nayoo.co/api/Nayoo/1602/show');
       
      $listdata=json_decode($get_data,true);
      // $listdata=json_decode(json_encode($get_data,true));

      // //print_r 
      // echo '<pre>';
      // print_r($listdata);
      // echo '</pre>';


    ?>

  <!-- Text Header -->
    <div class="header">
      <h2>Phone Book</h2>
      <p>ระบบโปรแกรมสมุดโทรศัพท์</p>
    </div>

<div class="row">

<!-- L-Side -->
  <div class="column1"></div>

<!-- Center Column -->
  <div class="column2">

    <!-- Navbar -->
    <div class="topnav">
      <a href="index.php">หน้าหลัก</a>
      <a href="create.php">เพิ่มข้อมูล</a>
      <a href="#">Link</a>
    </div>  

    <!--Head Forms 1-->
      <div class="row" style="margin: 35px 0px 35px 30px;">
        <i class="fa fa-edit" style="font-size:24px"> 
          <strong>แสดงข้อมูล</strong> 
        </i>
      </div>

    <!-- Show data 1-->
      <div class="content2">
        <div class="row">

         <table class="mytable2 fonttable">
          <thead class="thead2">
            <tr>
              <th >ID</th>
              <th >Name</th>
              <th >Organization</th>
              <th >Mobile Number</th>
              <th >Home Phone</th>
              <th >Office Number</th>
              <th >E-mail</th>
              <th >Image</th>
              <th >Created_at</th>
              <th >Updated_at</th>
              <th >Edit</th>
              <th >Delet</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td >0001</td>
              <td >ขอนแก่น น่าอยู่</td>
              <td >น่าอยู่ คอร์ปอเรชั่น จำกัด</td>
              <td >0619259998</td>
              <td >0619259998</td>
              <td >0619259998</td>
              <td >nayoo.corporation@gmail.com</td>
              <td >nayoo_khonkaen.jpg</td>
              <td >2021-12-22T03:04:02.000000Z</td>
              <td >2021-12-22T04:13:00.000000Z</td>
              <td ><a href='edit.php?id=<?php echo $row["id"];?>'>edit</a></td>
              <td ><a href='delete.php?id=<?php echo $row["id"];?>' onclick="return confirm('Do you want to delete this record? !!!')">del</a>
            </td> 
            </tr>
          </tbody>  
        </table>
 
        </div>
      </div>
      <!-- End Forms-->

  <!-- Footer -->
    <div class="footer">
        <strong>Copyright © 2022 Atchara.</strong>
    </div>

  </div>
  
  <!-- R-Side -->
  <div class="column3"></div>

</div> 



</body>
</html>


