<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="layout.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>


<title>Phone Book</title>

<style> </style>

</head>
<body>

  <!-- Text Header -->
    <div class="header">
      <h2>Phone Book</h2>
      <p>ระบบโปรแกรมสมุดโทรศัพท์</p>
    </div>
  
<div class="row">

<!-- L-Side -->
  <div class="column1"></div>

<!-- Center Column -->
  <div class="column2">

  <!-- Navbar -->
    <div class="topnav">
      <a href="index.php">หน้าหลัก</a>
      <a href="create.php">เพิ่มข้อมูล</a>
      <a href="#">Link</a>
    </div>
      
    <!--Head Forms 1-->
      <div class="row" style="margin: 35px 0px 35px 30px;">
        <i class="fa fa-search " style="font-size:24px"> 
          <strong>ค้นหาข้อมูล</strong> 
        </i>
      </div>

    <!-- Forms 1-->
      <div class="content">
        <div class="row">

          <form action="#" method="post">
            <center>
              <strong>ID :</strong>
              <input class="inputbox" type="text" name="id" id="id">
              <button class="button" style="background-color: #e3a343;" type="button" onclick="check()" ><i class="fa fa-search"></i>ค้นหา</button>
            <br>
              <p style="margin-top: 20px; color:red; ">** ไม่กรอกค่า ID คือการเลือกค้นหาข้อมูลทั้งหมด **</p>

            </center> 

          </form>
        </div>
      </div>
      <!-- End Forms-->

  <!-- Footer -->
    <div class="footer">
      <strong>Copyright © 2022 Atchara.</strong>
    </div>

  </div>
  
  <!-- R-Side -->
  <div class="column3"></div>

</div> 



</body>
</html>

<script type="text/javascript" src="js/index.js"></script>