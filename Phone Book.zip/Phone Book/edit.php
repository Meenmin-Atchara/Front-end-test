<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="layout2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>

<title>Phone Book</title>

<style> </style>

</head>
<body>

  <!-- Text Header -->
    <div class="header">
      <h2>Phone Book</h2>
      <p>ระบบโปรแกรมสมุดโทรศัพท์</p>
    </div>

<div class="row">

<!-- L-Side -->
  <div class="column1"></div>

<!-- Center Column -->
  <div class="column2">

    <!-- Navbar -->
    <div class="topnav">
      <a href="index.php">หน้าหลัก</a>
      <a href="create.php">เพิ่มข้อมูล</a>
      <a href="#">Link</a>
    </div>  

    <!--Head Forms 1-->
      <div class="row" style="margin: 35px 0px 35px 30px;">
        <i class="fa fa-edit" style="font-size:24px"> 
          <strong>แก้ไขข้อมูล</strong> 
        </i>
      </div>

    <!-- Forms 1-->
      <div class="content">
        <div class="row">

          <form action="#" method="post">
            <table class="mytable">
              <thead>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
              </thead>
              <tbody>
                <tr>
                  <td>ชื่อ:</td>
                  <td> <input type="text" name="name" id="name" value=""  placeholder="กรุณาระบุ ชื่อ"></td>
                  <td>E-mail:</td>
                  <td> <input type="text" name="email" id="email" value="" ></td>
                </tr>
                
                <tr>
                  <td>Organization:</td>
                  <td> <input type="text" name="organize" id="organize" value=""></td>
                  <td>Mobile Number: </td>
                  <td> <input type="text" name="mobile" id="mobile" value=""></td>
                </tr>
                
                <tr>
                  <td>Home Phone:</td>
                  <td> <input type="text" name="homephon" id="homephon" value=""></td>
                  <td>Office Number: </td>
                  <td> <input type="text" name="office" id="office" value=""></td>
                </tr>
                
              </tbody>  
            </table>
      
            <center style=" margin-top: 6%; margin-bottom: 3%;">
              <button class="button" style="background-color: #79C0E1;" type="submit" ><i class="fa fa-edit"></i>แก้ไขข้อมูล</button>
              <button class="button" style="background-color: #d7c128;" type="button" onclick="clearall()" ><i class="fa fa-close"></i>ยกเลิก</button>

            </center>

          </form>
        </div>
      </div>
      <!-- End Forms-->

  <!-- Footer -->
    <div class="footer">
       <strong>Copyright © 2022 Atchara.</strong>
    </div>

  </div>
  
  <!-- R-Side -->
  <div class="column3"></div>

</div> 



</body>
</html>

<script type="text/javascript" src="js/index.js"></script>