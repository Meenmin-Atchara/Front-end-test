
function createpage(){
	document.location='create.php'
}

function clearall(){
    // alert("Test");

    $("input:text").val("");

    // $("#tbody").empty();
}

function check(){
    // alert("success!");

    if($('#id').val() == null || $('#id').val() == "" ){

    alert('Search all ID.');
    window.location = 'show_all.php';

    }else{

        $.post( "show_id.php", {data:$('#id').val()}, function(data){
            alert('Search ID ='+$('#id').val());
            window.location.href = "show_id.php"
        });
    // alert('Search ID');
    // window.location = 'show_id.php';
    
    }

}

// function delet(){

//     if(isset($('#id').val()){
//         alert('test');
//          $.ajax({
//         url: '/script.cgi',
//         type: 'DELETE',
//         success: function(result) {
//         // Do something with the result
//     }
// });
//     }
   

// }