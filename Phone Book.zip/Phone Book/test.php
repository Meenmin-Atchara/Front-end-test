<?php

        $get_data=file_get_contents('https://test-frontend-api.nayoo.co/api/Nayoo/1602/index');
       
        $listdata=json_decode($get_data,true);
        // $listdata=json_decode(json_encode($get_data,true));

      //print_r 
      echo '<pre>';
      print_r($listdata);
      echo '</pre>';


        foreach($listdata as $row => $Array){
        // echo $Array . "<br/>";

        foreach($Array as $innerRow => $value){
        echo json_encode($value) . "<br/>";

        echo json_encode($value['id']) . "<br/>";
        echo json_encode($value['name']) . "<br/>";

  }
}


    ?>


       