<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="layout.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>


<title>Phone Book</title>

<style> </style>

</head>
<body>
  
  <?php
      error_reporting(0); 
      $get_data=file_get_contents('https://test-frontend-api.nayoo.co/api/Nayoo/1602/index');
       
      $listdata=json_decode($get_data,true);
      // $listdata=json_decode(json_encode($get_data,true));

      //print_r 
      // echo '<pre>';
      // print_r($listdata);
      // echo '</pre>';

  ?>


  <!-- Text Header -->
    <div class="header">
      <h2>Phone Book</h2>
      <p>ระบบโปรแกรมสมุดโทรศัพท์</p>
    </div>

<div class="row">

<!-- L-Side -->
  <div class="column1"></div>

<!-- Center Column -->
  <div class="column2"> 

  <!-- 1 Navbar -->
    <div class="topnav">
      <a href="index.php">หน้าหลัก</a>
      <a href="create.php">เพิ่มข้อมูล</a>
      <a href="#">Link</a>
    </div>  


    <!-- 2 Head Forms 1-->
      <div class="row" style="margin: 35px 0px 35px 30px;">
        <i class="fa fa-edit" style="font-size:24px"> 
          <strong>แสดงข้อมูล</strong> 
        </i>
      </div>


    <!-- 3 Show data 1-->
      <div class="content2">

        <table class="mytable2 fonttable">
          <thead class="thead2">
            <tr>
              <th style="width: 6%;">ID</th>
              <th style="width: 16%;">Name</th>
              <th style="width: 16%;">Organization</th>
              <th style="width: 13%;">Mobile Number</th>
              <th style="width: 13%;">Home Phone</th>
              <th style="width: 13%;">Office Number</th>
              <th style="width: 13%;">E-mail</th>
              <th style="width: 13%;">Image</th>
              <th style="width: 20%;">Created_at</th>
              <th style="width: 20%;">Updated_at</th>
              <th style="width: 10%;">Edit</th>
              <th style="width: 10%;">Delet</th>
            </tr>
          </thead>
          <tbody>
            <tr>

              <?php         
                foreach($listdata as $row => $innerArray){
                // echo $innerArray . "<br/>";

                foreach($innerArray as $innerRow => $value){
                // echo json_encode($value) . "<br/>";

                // echo json_encode($value['id']) . "<br/>";
          
              ?>

              <td style="width: 6%;"><?php  echo json_encode($value['id']) . "<br/>"; ?></td>
              <td style="width: 16%;"><?php  echo json_encode($value['name'], JSON_UNESCAPED_UNICODE) ; ?> </td>
              <td style="width: 16%;"><?php  echo json_encode($value['organization'], JSON_UNESCAPED_UNICODE) . "<br/>"; ?></td>
              <td style="width: 13%;"><?php  echo json_encode($value['mobilenumber']) . "<br/>"; ?></td>
              <td style="width: 13%;"><?php  echo json_encode($value['homephone']) . "<br/>"; ?></td>
              <td style="width: 13%;"><?php  echo json_encode($value['officenumber']) . "<br/>"; ?></td>
              <td style="width: 13%;"><?php  echo json_encode($value['email']) . "<br/>"; ?></td>
              <td style="width: 13%;"><?php  echo json_encode($value['image'], JSON_UNESCAPED_UNICODE) . "<br/>"; ?></td>
              <td style="width: 20%;"><?php  echo json_encode($value['created_at']) . "<br/>"; ?></td>
              <td style="width: 20%;"><?php  echo json_encode($value['updated_at']) . "<br/>"; ?></td>
              <td style="width: 10%;"><a href='edit.php?id=<?php echo json_encode($value['id']);?>'>edit</a></td>
              <td style="width: 10%;"><a href='delete_data.php?id=<?php echo json_encode($value['id']);?>' onclick="return confirm('Do you want to delete this record id=<?php echo json_encode($value['id']);?> ? !!!')">del</a>
              </td> 
            </tr>

          </tbody>   
            <?php 
                }
            }
            ?> 
      </table>  
      <!-- End Forms-->
    </div>



  <!-- Footer -->
    <div class="footer">
       <strong>Copyright © 2022 Atchara.</strong>
    </div>


  



  </div>




<!-- R-Side -->
  <div class="column3"></div>

</div>


</body>
</html>


<script type="text/javascript" src="js/index.js"></script>
